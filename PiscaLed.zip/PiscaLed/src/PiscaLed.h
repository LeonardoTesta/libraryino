#ifndef PiscaLed_h
#define PiscaLed_h

#include "Arduino.h"

class PiscaLed{ //CRIAÇÃO DA CLASSE PISCA LED.
  public:
    PiscaLed(byte pinLed, int tempoDelay = 200);
    void inicioPisca();
    void paraPisca();

  private:
    int tempo;
    byte pino;
};

#endif