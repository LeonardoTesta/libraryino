#include "PiscaLed.h"

#include <stdio.h>
#include <string.h>
#include <inttypes.h>
#include "Arduino.h"

PiscaLed::PiscaLed(byte pinLed, int tempoDelay){
  pinMode(pinLed, OUTPUT);
  pino = pinLed;
  tempo = tempoDelay;
}

void PiscaLed::inicioPisca(){
  digitalWrite(pino, HIGH);
  delay(tempo);
  digitalWrite(pino, LOW);
  delay(tempo);
  digitalWrite(pino, HIGH);
  delay(tempo);
}

void PiscaLed::paraPisca(){
  digitalWrite(pino, LOW);
  delay(1000);
}